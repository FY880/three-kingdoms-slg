# 三国 SLG 单机版 · 可运行 Demo 与逻辑层

> 配套《三国 SLG 单机版 · 游戏设计文档（GDD）》的**最小可玩原型**：验证「大地图迷雾 + 连地出征 + 地形/天气 + 庙算 + 伏击/水攻」核心手感。
> 形态：纯前端单机，无服务器、无依赖、无构建步骤。

## 快速运行

**方式 A（推荐，最稳）**：在 `/workspace` 目录下起一个本地静态服务器，浏览器打开 `http://localhost:8000`

```bash
cd /workspace
python3 -m http.server 8000
```

**方式 B**：直接双击 `index.html`（部分浏览器对 `file://` 加载本地脚本有限制，若地图空白请用方式 A）。

### 手机预览（iOS/安卓）
Demo 已是**手机优先 + 触控适配**（拖动平移、双指缩放、点按出征）。在电脑上起服务后，用手机连同一 WiFi 访问 `http://<电脑局域网IP>:8000`；或浏览器开 DevTools 切「设备模拟」即可。要上架 App Store / 应用市场，后续用 Cocos / Unity / Godot 把 `src/` 纯逻辑层接进原生工程导出即可（逻辑层零 DOM 依赖，详见 GDD §17.6）。

## 文件结构

```
/workspace
├── index.html          # 可运行 Demo（地图/迷雾/出征/庙算/伏击/水攻/多剧本/视觉表现层）
├── src/                # 纯逻辑层（UMD 模块，无 DOM 依赖，浏览器+Node 双兼容）
│   ├── util.js         # 通用工具 clamp/pick
│   ├── data.js         # 配表默认数据 + CSV 解析 + 热加载（可变 state）
│   ├── combat.js       # 环境结算器·兵书·战斗模拟·阵法选择·士气传染·水攻持续
│   ├── diplomacy.js    # 外交关系模型（同盟/敌对/附庸/议和/剧本事件）
│   ├── scenario.js     # 多剧本数据 SCENARIOS + 事件触发
│   └── rules.js        # 聚合入口：暴露 window.RULES / module.exports
├── dist/               # 引擎移植包（由 tools/build-bundle.js 生成）
│   └── rules.bundle.js # 单文件 UMD 包：引擎即插即用（Godot/Cocos/Unity）
├── tools/              # 工程脚本
│   ├── build-bundle.js # 从 src/ 生成 dist/rules.bundle.js
│   └── engine-adapter.js # 引擎接入示例（加载 bundle→注入 CSV→推演）
├── data/               # 配表模板（CSV，数值可自由调）
│   ├── terrain.csv     # 12 种地形：移动/攻防/兵种适配/伏击/洪水/天险
│   ├── weather.csv     # 6 种天气：火攻/骑兵/侦察/洪水系数
│   ├── season.csv      # 4 季天气权重 + 农时产出
│   ├── generals.csv    # 12 名武将（历史人名 + 原创战法文案）
│   └── formations.csv  # 6 种阵法数值
└── tests/              # 验证工具
    ├── smoke.js        # DOM 桩冒烟测试（44 PASS）
    ├── unit.js         # 模块化单元测试（44 PASS）
    ├── balance.js      # 自动平衡脚本（五维度：武将/地形/天气/阵容/兵种）
    └── balance_report.md  # 平衡脚本生成的报告
```

## Demo 操作

- **黄色高亮** = 可进攻目标（与己方领地相邻，体现「连地」规则）。
- 点击高亮地块 → 弹出**庙算**（天时/地利/人和评分 + 预测胜率）→ 自动结算战斗。
- **推进时辰**：切换季节与随机天气（雨→可水攻、雾→伏击加成、风/旱→火攻强），**同时触发 4 个 AI 诸侯自动铺路扩张、互相攻伐、甚至反打你**。
- **AI 诸侯**：曹操·魏(霸权)/刘备·蜀(外交)/孙权·吴(稳健)/董卓(侵略)，各有性格与目标评分；势力榜见上滑面板的「📊 势力」。
- **伏兵模式**：在己方领地旁的**森林**布伏，敌侦察不到则首回合突袭。
- **水攻模式**：点**低洼**地块，需「己控上游河流 + 雨季/融雪」，水淹敌军。
- **外交模式**：点**诸侯地块**打开盟约面板，可与该势力切换 **同盟 / 中立 / 敌对 / 附庸**，并可**议和**（接受度由你的「信誉」决定，高信誉更易停战，背信则有长期代价）。同盟=互不侵犯；敌对=你与盟友**优先夹击**该诸侯（「拉一个 AI 打另一个」）；附庸=该势力臣服、双方互不侵犯；**借道行军**允许借相邻同盟格迂回抵达目标（假道伐虢）。
- **剧本**：点「剧本」打开选择面板，可切换 **群雄逐鹿 / 黄巾之乱 / 讨董卓**。每剧本的诸侯阵容、你的出生点、中立强度、胜利条件与剧本事件都不同；切换即重开一局（外交关系与信誉一并重置）。
- **地图视觉表现层**：格子中央绘制地形汉字（山/林/水/城…），不同势力领地以彩色描边勾勒清晰边界；天气以全屏色调 + 轻量粒子表现（雨丝/雪点/雾团/风线/旱纹），晴天不开启动画以省电；**镜头缓动自动运镜**到战斗/事件焦点；战斗含**飘字/闪光/屏幕抖动/暗角**反馈提升打击感；与玩家领地相邻的中立/敌格以**黄色描边**提示可出征。
- **配表（热加载）**：改完 `data/*.csv` 后点此按钮，自动重新拉取并热替换内存数据表，**数值即时生效、无需刷新页面**（需以方式 A 的本地服务器运行，因用到 `fetch`）。

## 核心机制（已在逻辑层实现）

| 机制 | 函数 | 说明 |
|---|---|---|
| 环境结算器 | `environmentModifiers` | 地形×天气×兵种 综合修正 |
| 天险惩罚 | `chokePenalty` | 山地/城池/隘口攻方受罚（≈0.6×） |
| 武将克制 | `styleCoef` / `suitCoef` | 鹰扬>持重>奇变>鹰扬；兵种适性 S/A/B/C |
| 兵书指令 | `waterAttack` / `emptyFort` / `ambushDetect` | 水攻 / 空城计 / 埋伏判定 |
| 庙算 | `miaoSuan` | 天时/地利/人和 三维评分 |
| 战斗模拟 | `simulateCombat` | 回合制战法演算（10 回合封顶，第 7 回合起猝死递增）；含风格克制/伏击/水攻/士气传染 |
| 士气传染 | `squadMoraleContagion` | 同袍情绪向均值靠拢；溃逃连累全军 |
| 阵法选择 | `chooseFormation` | AI 按攻防/包抄/天险/克制打分选阵，高阶阵需智力解锁 |
| 水攻持续 | `startFlood`/`tickFlood`/`floodDuration` | 依天气洪水系数决定持续回合，每回合结算并递减 |
| 外交关系 | `createDiplomacy`/`isAlly`/`isRival`/`diploScoreAdj`/`setVassal`/`peaceAcceptChance` | 同盟互不侵犯、附庸臣服、敌对优先夹击；信誉影响议和；接入 AI 评分 |
| 剧本事件 | `applyScenarioEvent`/`eventsDueAt` | `rivalAll`(众矢之的)/`allyAll`(讨贼同盟) 等脚本化关系变更 |
| 多剧本 | `SCENARIOS`/`getScenario` | 诸侯阵容/出生点/中立倍率/胜利条件作为数据；切换即重开 |
| 配表热加载 | `parseCSV`/`reload`/`loadConfigFromServer`/`loadCSVFromDir` | CSV → 内存数据表即时替换（数值与代码分离） |

## 如何扩展（给个人开发者）

1. **调数值**：直接改 `data/*.csv` 里的系数，回 Demo 点「配表」按钮即热替换；Node 侧用 `R.loadCSVFromDir('data')` 批量校验。
2. **自动平衡**：`node tests/balance.js` 跑五维度可复现模拟（武将全序对局 / 地形镜像 / 天气 / **阵容全序循环** / **兵种克隆隔离**），输出 `balance_report.md`，标出过强/过弱武将·阵容、过/欠防御地形、过强/过弱兵种——调平有数据支撑、可复现。
3. **加武将/战法**：往 `generals.csv` 加行，遵循「历史人名可用、战法文案原创」（见 GDD 第 10 节合规）。
4. **加 AI 势力 / 剧本**：`scenario.js` 的 `SCENARIOS` 是纯数据，加一条即可开新剧本；`combat.js` 已留 `makeUnit`/`simulateCombat`/`chooseFormation` 接口，AI 只需每时辰调用决策 + 出征。
5. **模块化与单测**：逻辑层按 `util/data/combat/diplomacy/scenario` 拆分，均 UMD 双兼容；`node tests/unit.js` 跑隔离单测（44 PASS）。
6. **接渲染 / 引擎移植**：`index.html` 的 `render()` 为 Canvas 实现，可整段替换；更省事的是用 `dist/rules.bundle.js` 单文件 UMD 包——`node tools/build-bundle.js` 重新生成，引擎只拿这一个文件：`import R from './rules.bundle'`（Cocos ts）/ Godot JS Bridge 执行后读全局 `RULES` / Unity 作 `.jslib`。逻辑层零 DOM 依赖，可整体平移（详见 GDD §17.6 与 `tools/engine-adapter.js`）。

### 手机 / 离线试玩（不依赖电脑或服务）
`index.html` 用 `fetch` 拉取 `data/*.csv`，手机浏览器在 `file://` 下会被 CORS 拦截。**解决：生成单文件离线版**：
```bash
node tools/build-standalone.js      # 产出 dist/index.standalone.html
```
该文件把 6 个逻辑模块内联、5 张 CSV 嵌成字符串，启动时 `parseCSV + reload` 注入内存数据表（即调平后的数值），并让「配表」按钮离线也能热重载——**零 fetch、零服务器**。把 `dist/index.standalone.html` 这一个文件发到手机（微信/邮件/云盘/USB 均可），用手机浏览器打开即可游玩；也可直接托管到任意静态空间（GitHub Pages / Netlify Drop）后手机访问网址。

> 若想用电脑局域网临时联调：在仓库根目录 `python3 -m http.server 8080`，手机连同一 WiFi 访问 `http://<电脑局域网IP>:8080`，即可跑原版 `index.html`（数据走 http 正常加载）。

## 验证记录

- **逻辑层（Node）**：环境结算、水攻（雨季低洼持续回合灭敌）、庙算、战斗（平原/山地/伏击/猝死阶段）、士气传染、CSV 热加载数值生效、多剧本数据与事件触发，均正常。
- **冒烟测试** `node tests/smoke.js`（**44 项 PASS**）：地图生成、渲染（地形字形/势力边界/多种天气粒子/镜头缓动）、庙算、战报、外交结盟保护、共同讨伐评分、附庸/议和、配表热加载、**多剧本切换与阵容/出生点差异**、剧本事件 `rivalAll` 触发、**胜负判定**、**AI 持续扩张**，均通过。
- **单元测试** `node tests/unit.js`（**44 项 PASS**）：util/data/combat/diplomacy/scenario 隔离单测 + 聚合入口集成（含热加载实时一致）。
- **自动平衡** `node tests/balance.js`：可复现五维度模拟，生成 `balance_report.md`；当前 12 名武将与 12 种地形全数进入「正常」区间（综合力标准差 10.3%），兵种三系跨地形均衡（std 0.7%），阵容按全序循环给出过强/过弱组合（如周瑜+吕布偏强、刘备+张飞偏弱）与协同度。

> 合规提示：本 Demo 武将用历史人名、战法文案为原创示例；上线前请按 GDD 第 10 节完成素材授权自查。
